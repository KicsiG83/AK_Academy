package helper.generate;

import java.security.SecureRandom;
import java.util.*;

import static misc.validate.Assert.assertGreaterThan;
import static misc.validate.Assert.assertNotNull;

/**
 * Az <code>IPasswordGenerator</code> interfész implementációja, mely
 * a kapott karkterkészlet felhasználásával generál le egy random
 * szöveget, mely jelszóként felhasználható.
 */
public class PasswordGenerator implements IPasswordGenerator {

    private final Random random;
    private final List<CharacterSet> characterSets;

    public PasswordGenerator(final List<CharacterSet> characterSets) {
        this(new SecureRandom(), characterSets);
    }

    public PasswordGenerator(final CharacterSet[] characterSets) {
        this(new SecureRandom(), Arrays.asList(characterSets));
    }

    public PasswordGenerator(final Random random, final CharacterSet[] characterSets) {
        this(random, Arrays.asList(characterSets));
    }

    public PasswordGenerator(final Random random, final List<CharacterSet> characterSets) {
        assertNotNull("The Random instance parameter should not be null", random);
        assertNotNull("characterSets parameter should not be null", characterSets);
        this.random = random;
        this.characterSets = characterSets;
    }

    @Override
    public String generatePassword(final int length) {
        assertGreaterThan(
                "length should be greater than the number of the given character sets",
                characterSets.size(),
                length);
        return createPassword(random, length);
    }

    @Override
    public String generatePasswordExtended(final int length) {
        assertGreaterThan(
                "length should be greater than the number of the given character sets",
                characterSets.size(),
                length);
        return createPassword(new SecureRandom(), length);
    }

    private boolean isAllElementHasUsed(final Map<CharacterSet, Boolean> characterSet) {
        List<Boolean> usage = new ArrayList<>(characterSet.size());
        characterSet.forEach((characterSet1, aBoolean) -> usage.add(aBoolean));
        return usage.contains(false);
    }

    // TODO unit tesztet megírni!
    private String createPassword(final Random random, final int length) {
        final Map<CharacterSet, Boolean> selected = fillMapFromSelectedCharacterSets(characterSets);

        final StringBuilder sb = new StringBuilder();
        while (isAllElementHasUsed(selected)) {
            sb.delete(0, sb.length());
            List<CharacterSet> actualCharacterSets = new ArrayList<>(selected.keySet());
            Collections.shuffle(actualCharacterSets);
            for (int i = 0; i < length; i++) {
                final CharacterSet selectedSet = actualCharacterSets.get(random.nextInt(actualCharacterSets.size()));
                final String setAsString = selectedSet.getCharacters();
                sb.append(setAsString.charAt(random.nextInt(setAsString.length() - 1)));
                selected.replace(selectedSet, true);
            }
        }
        return sb.toString();
    }


    // TODO unit tesztet megírni!
    private Map<CharacterSet, Boolean> fillMapFromSelectedCharacterSets(final List<CharacterSet> characterSets) {
        final Map<CharacterSet, Boolean> selected = new LinkedHashMap<>(characterSets.size());
        for (final CharacterSet cs : characterSets) {
            selected.put(cs, false);
        }
        return selected;
    }

}
