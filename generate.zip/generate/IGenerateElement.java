package helper.generate;

import java.util.List;

/**
 * Bizonyos összetettebb elemeg legenerálásáért felelős függvények halmaza.
 *
 * @since 0.3.13
 */
public interface IGenerateElement {

    /**
     * A megadott paraméterek alapján legenerálja a telefonszámot, '+' jellel
     * az elején opcionálisan.
     *
     * @param length            a kívánt teljes telefonszám hosszúsága
     * @param countryCallerCode a telefonszám országhívó kódja
     * @param networkIDNumber   a telefonszám hívó/szolgáltató azonosítója
     * @param plusSign          annak eldöntése, hogy '+' jellel az elején térjen-e
     *                          vissza a függvény
     * @return visszaadja a paraméterek szerint összeállított telefonszámot
     */
    String generatePhoneNumber(final int length, final int countryCallerCode, final int networkIDNumber, final boolean plusSign);

    /**
     * Hasonló a fenti függvényhez, mindössze annyiban tér el, hogy az ország-
     * és szolgáltató azonosító itt String inputként van értelmezve.
     *
     * @param length            a kívánt teljes telefonszám hosszúsága
     * @param countryCallerCode a telefonszám országhívó kódja
     * @param networkIDNumber   a telefonszám hívó/szolgáltató azonosítója
     * @param plusSign          annak eldöntése, hogy '+' jellel az elején
     *                          térjen-e vissza a függvény.
     * @return visszaadja a paraméterek szerint összeállított telefonszámot
     */
    String generatePhoneNumber(final int length, final String countryCallerCode, final String networkIDNumber, final boolean plusSign);

    /**
     * Telefonszám összeállító függvény, mely a szolgáltató azonosító figyelembe
     * vétele nélkül generál tartalmat.
     *
     * @param length            a kívánt teljes telefonszám hosszúsága
     * @param countryCallerCode a telefonszám országhívó kódja
     * @param plusSign          annak eldöntése, hogy '+' jellel az elején
     *                          térjen-e vissza a függvény.
     * @return visszaadja a paraméterek szerint összeállított telefonszámot
     */
    String generatePhoneNumber(final int length, final String countryCallerCode, final boolean plusSign);


    /**
     * A legegyszerűbb telefonszám generátor, mely mindössze hosszúságot kér
     * illetve hogy '+' jellel vagy anélkül térjen-e vissza.
     *
     * @param length   a kívánt teljes telefonszám hosszúsága
     * @param plusSign annak eldöntése, hogy '+' jellel az elején
     *                 térjen-e vissza a függvény.
     * @return visszaadja a paraméterek szerint összeállított telefonszámot
     */
    String generatePhoneNumber(final int length, final boolean plusSign);

    /**
     * Legenerál egy rendszámot, melynek formátuma alapértelmezetten magyar:
     * három angol abc-s karaktert követően három szám követ.
     * <code>regex: ([A-Z]{3}[0-9]{3})</code>
     *
     * @return visszatér a legenerált rendszámmal
     */
    String generatePlateNumber();

    /**
     * Legenerál egy alapértelmezetten magyar rendszámformátumó rendszámot,
     * mely nem szerepel a kapott listában.
     *
     * @param plateNumbersWhichAlreadyExits a lista, mellyel összehasonlításra
     *                                      kerül az aktuálisan legenerált
     *                                      rendszám.
     * @return visszatér a listában nem szereplő rendszámmal
     */
    String getPlateNumberWhichDoesNotExists(final List<String> plateNumbersWhichAlreadyExits);

    /**
     * Legenerál egy rendszámot, melyben a megadott számú karakter és szám
     * található úgy, hogy karaktert szám követ.
     *
     * @param numberLength   a kívánt számok mennyisége darabra a rendszámban
     * @param alphabetLength a kívánt betűk száma darabra a rendszámban
     * @return visszatér a paramétereknek megefelő rendszámmal
     */
    String generatePlateNumber(final int numberLength, final int alphabetLength);

    /**
     * Legenerál egy rendszámot a megadott betű és szám mennyiséggel úgy, hogy
     * az nem szerepel a megadott listában.
     * A legenerált rendszám formátuma olyan, hogy (ha egyik érték sem nulla,
     * a betűket számok követik.
     *
     * @param plateNumbersWhichAlreadyExits a lista, melyben nem szerepelhet a
     *                                      legenerált rendszám.
     * @param numberLength                  a kívánt számok mennyisége darabra a
     *                                      rendszámban
     * @param alphabetLength                a kívánt betűk száma darabra a
     *                                      rendszámban
     * @return paramétereknek megefelő rendszámmal, mely nem szerepel a
     * megadott listában.
     */
    String getPlateNumberWhichDoesNotExists(final List<String> plateNumbersWhichAlreadyExits,
                                            final int numberLength,
                                            final int alphabetLength);

}
