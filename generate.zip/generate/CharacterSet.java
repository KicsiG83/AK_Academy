package helper.generate;

/**
 * Karakterkészletet definiáló osztályok interfésze a jelszógenerátor
 * osztály számára.
 */
public interface CharacterSet {

    /**
     * Visszaadja az összeállított karakterkészletet egy önálló String-ben.
     *
     * @return A karakterkészlet elemei egy String-ként.
     */
    String getCharacters();

}
