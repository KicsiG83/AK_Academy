package helper.generate;

/**
 * Az angol abc elemeit, illetve számokat és speciális karaktereket tartalmazó
 * enumerátor.
 */
public enum EnglishCharacterSet implements CharacterSet {

    LOWER_CASE("abcdefghijklmnopqrstuvwxyz"),
    UPPER_CASE("ABCDEFGHIJKLMNOPQRSTUVWXYZ"),
    ALPHABETICAL(UPPER_CASE.getCharacters() + LOWER_CASE.getCharacters()),
    NUMBERS("0123456789"),
    SPECIAL("§'\"+!%/=()|~ˇ^˘°˛`˙´˝¨¸Ä€÷×đĐ[]łŁ$ß¤<>#&@{};*-.,");

    private String characterSet;

    EnglishCharacterSet(final String characterSet) {
        this.characterSet = characterSet;
    }

    public String getCharacters() {
        return characterSet;
    }

}
