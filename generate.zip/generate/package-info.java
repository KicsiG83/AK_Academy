/**
 * A tesztesetek készítése közben előforduló adatgenerálási igények
 * kiszolgálását segítő osztályok gyűjteménye
 */
package helper.generate;