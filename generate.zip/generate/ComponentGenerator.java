package helper.generate;

import java.util.Random;

import static misc.validate.Assert.assertNotNull;

/**
 * Alapvető elemek generálására használatos osztály, mely karaktert és számot
 * készít.
 *
 * @since 0.3.13
 */
public class ComponentGenerator implements IGenerateRandomComponents {

    /**
     * Az ascii tábla legkisebb értékű nagybetűs karakterének ('A') decimális
     * értéke
     */
    private static final int MIN_VALUE_OF_UPPER = 65;

    /**
     * Az ascii tábla legnagyobb értékű nagybetűs karakterének ('Z') decimális
     * értéke
     */
    private static final int MAX_VALUE_OF_UPPER = 90;

    /**
     * Az ascii tábla legkisebb értékű kisbetűs karakterének ('a') decimális
     * értéke
     */
    private static final int MIN_VALUE_OF_LOWER = 97;

    /**
     * Az ascii tábla legnagyobb értékű kisbetűs karakterének ('z') decimális
     * értéke
     */
    private static final int MAX_VALUE_OF_LOWER = 122;
    private final Random random;


    public ComponentGenerator(final Random random) {
        assertNotNull("The Random instance parameter should not be null", random);
        this.random = random;
    }

    @Override
    public char generateRandomChar(final boolean possibleOfLowerCase) {
        if (possibleOfLowerCase) {
            if ((random.nextInt() % 2 == 0)) {
                return getLowerCaseLetter();
            } else {
                return getUpperCaseLetter();
            }
        } else {
            return getUpperCaseLetter();
        }
    }

    @Override
    public int generateRandomInteger(final int minValue, final int maxValue) {
        return random.nextInt(maxValue - minValue) + minValue;
    }

    /**
     * Generál egy random kisberűs karaktert az angol abc karakterkészletéből.
     *
     * @return visszaadja a legenerált karaktert
     */
    private char getLowerCaseLetter() {
        return (char) (generateRandomInteger(MIN_VALUE_OF_LOWER, MAX_VALUE_OF_LOWER));
    }

    /**
     * Generál egy random nagyberűs karaktert az angol abc karakterkészletéből.
     *
     * @return visszaadja a legenerált karaktert
     */
    private char getUpperCaseLetter() {
        return (char) (generateRandomInteger(MIN_VALUE_OF_UPPER, MAX_VALUE_OF_UPPER));
    }

    @Override
    public String toString() {
        return "ComponentGenerator{" +
                "Lower case characters from '" + (char) MIN_VALUE_OF_LOWER +
                "' to '" + (char) MAX_VALUE_OF_LOWER +
                "', Upper case characters from '"
                + (char) MIN_VALUE_OF_UPPER + "' to '" +
                (char) MAX_VALUE_OF_UPPER + "'. The class using " +
                "the characters decimal values to generate them. " +
                "Random object: " + random + "}";
    }

}