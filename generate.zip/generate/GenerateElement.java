package helper.generate;

import java.util.List;

import static misc.validate.Assert.assertNotNull;

/**
 * @since 0.3.13
 */
public class GenerateElement implements IGenerateElement {

    private final IGenerateRandomComponents generateComponents;

    public GenerateElement(final IGenerateRandomComponents generateComponents) {
        assertNotNull("IGenerateRandomComponents implementation instance " +
                "should not be null", generateComponents);
        this.generateComponents = generateComponents;
    }

    public String generatePhoneNumber(final int length, final int countryCallerCode, final int networkIDNumber, final boolean plusSign) {
        final int lengthOfFullPhoneNumber = decideLength(length, String.valueOf(countryCallerCode), String.valueOf(networkIDNumber), plusSign);
        final StringBuilder builder = new StringBuilder(lengthOfFullPhoneNumber);
        if (plusSign) {
            builder.append('+');
        }
        appender(builder, String.valueOf(countryCallerCode), String.valueOf(networkIDNumber), generatedPhoneNumberBody(length));
        return builder.toString();
    }

    public String generatePhoneNumber(final int length, final String countryCallerCode, final String networkIDNumber, final boolean plusSign) {
        return generatePhoneNumber(length, Integer.valueOf(countryCallerCode), Integer.valueOf(networkIDNumber), plusSign);
    }

    public String generatePhoneNumber(final int length, final String countryCallerCode, final boolean plusSign) {
        final int lengthOfFullPhoneNumber = decideLength(length, countryCallerCode, "", plusSign);
        final StringBuilder builder = new StringBuilder(lengthOfFullPhoneNumber);
        if (plusSign) {
            builder.append('+');
        }
        appender(builder, countryCallerCode, generatedPhoneNumberBody(length));
        return builder.toString();
    }

    public String generatePhoneNumber(final int length, final boolean plusSign) {
        final int lengthOfFullPhoneNumber = decideLength(length, "", "", plusSign);
        final StringBuilder builder = new StringBuilder(lengthOfFullPhoneNumber);
        if (plusSign) {
            builder.append('+');
        }
        appender(builder, generatedPhoneNumberBody(length));
        return builder.toString();
    }

    // ------------- Rendszám generátor ------------- //

    public String generatePlateNumber() {
        int numberLength = 3;
        int alphabetLength = 3;
        return generateRandomAlphabets(alphabetLength) + generateRandomNumbers(numberLength);
    }

    public String getPlateNumberWhichDoesNotExists(final List<String> plateNumbersWhichAlreadyExits) {
        String plateNumber;
        do {
            plateNumber = generatePlateNumber();
        } while (plateNumbersWhichAlreadyExits.contains(plateNumber));
        return plateNumber;
    }

    public String generatePlateNumber(final int numberLength, final int alphabetLength) {
        return generateRandomAlphabets(alphabetLength) + generateRandomNumbers(numberLength);
    }

    public String getPlateNumberWhichDoesNotExists(final List<String> plateNumbersWhichAlreadyExits,
                                                   final int numberLength,
                                                   final int alphabetLength) {
        String plateNumber;
        do {
            plateNumber = generatePlateNumber(numberLength, alphabetLength);
        } while (plateNumbersWhichAlreadyExits.contains(plateNumber));
        return plateNumber;
    }

    /**
     * Legenerál egy stringet, mely random kisbetűs karaktereket fog
     * tartalmazni a kapott hosszúságban.
     *
     * @param count annak száma, hogy milyen hosszú legyen a kapott
     *              karakterhalmaz
     * @return a legenerált random karaktereket tartalmazó szöveg
     */
    private String generateRandomAlphabets(final int count) {
        final StringBuilder sb = new StringBuilder(count);
        for (int i = 0; i < count; i++) {
            sb.append(generateComponents.generateRandomChar(false));
        }
        return sb.toString().toUpperCase();
    }

    /**
     * Legenerál egy stringet, mely random számokat fog tartalmazni a kapott
     * hosszúságban.
     *
     * @param count annak száma, hogy milyen hosszú legyen a kapott
     *              szám
     * @return a legenerált random szám, String formában
     */
    private String generateRandomNumbers(final int count) {
        final StringBuilder resultNumbers = new StringBuilder(count);
        for (int i = 0; i < count; i++) {
            resultNumbers.append(generateComponents.generateRandomInteger(0, 9));
        }
        return resultNumbers.toString();
    }


    /**
     * A kapott StringBuilder objektumban hozzá-/összefűzi a paraméterül kapott
     * tömb elemeit.
     *
     * @param stringBuilder Az összefűzésre használt StringBuilder objektum,
     *                      melynek tartalma kerül változtatásra a függvényen
     *                      belül.
     * @param components    A tartalom, melyek egymás után kerülnek hozzáadásra
     *                      a StringBuilderben.
     */
    private void appender(final StringBuilder stringBuilder, final String... components) {
        for (final String component : components) {
            stringBuilder.append(component);
        }
    }


    /**
     * A kapott paraméterek alapján eldönti, hogy a leendő telefonszám milyen
     * hosszú lesz majd, ezáltal támogatva a többi függvényt és csökkentve a
     * kódismétlést.
     *
     * @param length            a felhasználó által elvárt hossz
     * @param countryCallerCode a kapott országhívó kód
     * @param networkIDNumber   a kapott szolgáltató azonosító kód
     * @param plusSign          döntés arról, hogy legyen-e '+' jel a generált
     *                          telefonszám elején vagy sem.
     * @return visszatér a paraméterek alapján kiszámított leendő teljes
     * hosszal.
     */
    private int decideLength(final int length,
                             final String countryCallerCode,
                             final String networkIDNumber,
                             final boolean plusSign) {
        final int finalLength;
        final int actualCountryCallerCodeLength = (countryCallerCode != null) ? String.valueOf(countryCallerCode).length() : 0;
        final int actualNetworkIDNumberLength = (networkIDNumber != null) ? String.valueOf(networkIDNumber).length() : 0;
        if (plusSign) {
            finalLength = length + actualCountryCallerCodeLength + actualNetworkIDNumberLength + 1;
        } else {
            finalLength = length + actualCountryCallerCodeLength + actualNetworkIDNumberLength;
        }
        return finalLength;
    }


    /**
     * A kapott IGenerateRandomComponents implementáció segítségével
     * legenerálja a megadott hosszúságú random számok halmazát.
     *
     * @param length a kívánt telefonszám hossz. Fontos, hogy ez
     *               nem okvetlen a teljes telefonszám hossza,
     *               hanem lehet csak egy része (pl. ha meg van
     *               adva ország és/vagy szolgáltatói kód, akkor
     *               csak az utána levő számjegyek számát kell megadni
     *               paraméterként.
     * @return visszatér a legenerált számsorozattal mint szöveg.
     */
    private String generatedPhoneNumberBody(final int length) {
        final StringBuilder builder = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            builder.append(generateComponents.generateRandomInteger(0, 9));
        }
        return builder.toString();
    }

}
