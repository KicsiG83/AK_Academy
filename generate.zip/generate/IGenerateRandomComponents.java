package helper.generate;

/**
 * @since 0.3.13
 */
public interface IGenerateRandomComponents {

    /**
     * Legenerál egy karaktert, mely a booleanként megadott értéktől függően
     * lehet kis- vagy nagybetűs.
     *
     * @param possibleOfLowerCase annak megengedése hogy a kapott karakter
     *                            <u>lehet</u>-e nagybetűs
     * @return visszatér a paramétertől függőenn kis-/nagybetűs karakterrel
     */
    char generateRandomChar(final boolean possibleOfLowerCase);


    /**
     * Legenerál egy random számot a megadott alsó és felső határértékeken
     * belül.
     *
     * @param minValue a legkisebb érték, amit felvehet a szám
     * @param maxValue a legnagyobb érték, amit felveet a szám
     * @return visszatér a határértékeknek megfelelő számmal
     */
    int generateRandomInteger(final int minValue, final int maxValue);

}
