package helper.generate;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static misc.validate.Assert.assertNotNull;

/**
 * Biztosítja azon függvén(eke)t, mellyel/melyekkel az adott
 *
 * @since 0.3.13
 */
public final class GenerateCurrentDate {

    private GenerateCurrentDate() {
        // privát konstruktor az egyetlen statikus függvény okán
    }

    /**
     * Legenerálja a kapott pattern alapján az aktuális dátumot.
     *
     * @param pattern A dátumformátum mintája, mely szerint formázva
     *                szeretnénk az aktuális időpontot megkapni.
     * @return Az aktuális időpont a kért formátum szerint.
     */
    public static String getDateFromPattern(final String pattern) {
        assertNotNull("date pattern should not be null", pattern);
        final Date date = new Date();
        final Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        return new SimpleDateFormat(pattern).format(cal.getTime());
    }


}
