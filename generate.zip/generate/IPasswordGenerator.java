package helper.generate;

public interface IPasswordGenerator {

    /**
     * Legenerál egy, az implementált osztályban megadott karakterkészlet
     * alapján egy jelszót. (kvázi random string-et).
     *
     * @param length A generált jelszó kívánt hossza
     * @return A karakterkészletből random kiválogatott, a megadott
     * hossznak megfelelő jelszó
     */
    String generatePassword(int length);

    /**
     * Az implementált osztályban megadott karakterkészletek alapján
     * legenerál egy, a függvény argumentumban átadott hosszúságú
     * jelszót. Működése annyiban tér el a
     * <code>generatePassword</code> függvény működésétől, hogy
     * ez a megadott karakterkészleteket külön kezeli, azokból
     * szintén random választ, majd azokból választ random értéket.
     * Használata több karakterkészlet megadásánál javasolt, különben
     * túl költséges.
     *
     * @param length A generált jelszó kívánt hossza
     * @return A karakterkészletből random kiválogatott, a megadott
     * hossznak megfelelő jelszó
     */
    String generatePasswordExtended(int length);

}
